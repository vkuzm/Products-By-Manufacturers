<?php
// Heading
$_['heading_title'] = 'Товары от производителей';
// Text
$_['text_reviews']  = 'На основании %s отзывов.';
?>