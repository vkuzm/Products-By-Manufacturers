<?php
// Heading 
$_['heading_title'] = 'Product from manufacturers';

// Text
$_['text_reviews']  = 'Based on %s reviews.'; 
?>