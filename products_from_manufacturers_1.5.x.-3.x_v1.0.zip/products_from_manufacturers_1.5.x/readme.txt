
Plugin name: Products From Manufacturers
Version: 1.0

Author: Azeroth
Website: http://web-azeroth.com

Description:
You can make custom product list by manufacturers in home or another page. 

=======================================
Installation:

1. Upload files from "upload" folder
2. Go to "Extensions - Modules" find "Products From Manufacturers" and configure it
3. Do not forget choose this module in Layouts page.