<?php
// Heading
$_['heading_title'] = 'Product from manufacturers';

// Text
$_['text_tax']      = 'Ex Tax:';